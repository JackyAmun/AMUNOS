AMUNOS GUI v0.5 source backup

Contains the kernel GUI implementation, user GUI demo, WRITE GUI entry, and the distribution build files as of 2026-10-04.
The current distribution omits GUI and WRITE binaries, while GUI sources remain available in the main tree.
